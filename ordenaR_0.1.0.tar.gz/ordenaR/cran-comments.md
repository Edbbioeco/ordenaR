## Test environments
* Local Windows 11 install, R 4.5.2
* R-hub Windows, macOS, and Ubuntu checks
* GitHub Actions (R 4.3, 4.4, devel)

## R CMD check results
There were no ERRORs or WARNINGs or NOTEs. 

## Downstream dependencies
This is a new submission to CRAN.
