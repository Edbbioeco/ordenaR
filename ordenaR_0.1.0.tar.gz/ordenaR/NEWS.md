# ordenaR 0.1.0

* Initial release of the package.
* Provides tools for ecological data organization and ordination.
* Includes example dataset `data_ordenar`.
